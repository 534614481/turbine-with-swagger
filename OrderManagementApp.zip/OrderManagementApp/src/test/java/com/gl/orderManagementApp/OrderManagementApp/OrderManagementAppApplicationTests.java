package com.gl.orderManagementApp.OrderManagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
